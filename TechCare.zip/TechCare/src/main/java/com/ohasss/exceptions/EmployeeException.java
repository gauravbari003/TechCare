package com.ohasss.exceptions;

public class EmployeeException extends Exception {
	
	public EmployeeException() {
		// TODO Auto-generated constructor stub
	}
	
	public EmployeeException(String message) {
		super(message);
	}

}
