package com.ohasss.exceptions;

public class HODException extends Exception {
	
	public HODException() {
		// TODO Auto-generated constructor stub
	}
	
	public HODException(String message) {
		super(message);
	}

}
