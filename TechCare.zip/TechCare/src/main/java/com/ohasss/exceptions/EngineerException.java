package com.ohasss.exceptions;

public class EngineerException extends Exception {
	
	public EngineerException() {
		// TODO Auto-generated constructor stub
	}
	
	public EngineerException(String message) {
		super(message);
	}

}
